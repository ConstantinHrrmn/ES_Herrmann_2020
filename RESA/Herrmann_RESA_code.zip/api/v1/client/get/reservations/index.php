<?php

// On inclu le connecteur de la base de données
include '../../pdo.php';