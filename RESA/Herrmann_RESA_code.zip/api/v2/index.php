<?php

echo "RESA API by Constantin Herrmann";