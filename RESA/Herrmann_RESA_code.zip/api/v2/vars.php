<?php
header("Access-Control-Allow-Origin: *");

// Ce fichier regroupe toutes les variables globale que j'utilise dans plusieurs fichiers

// Le chemin complet jusqu'à l'API
$FullPathToAPI = "http://10.0.0.3/Travail_diplome_ES_2020/RESA/api/v2/";

// Une clé qui sera hashée avec le mot de passe pour pouvoir le stocker de manière sécurisée dans la base de données
// Cette clé sera certainement stockée autre part dans le futur
$key = "u7csu5qH6Cp9xWkrIgtGvTsOosnKvH9RhQOXteJtNhknqrEHcjp8dCGYuv02SBoHGsBRoN0zGeGeToULmWUDTb2HAgnSGntNJHmg";