<?php



// Le chemin jusqu'à l'API
$path = "http://10.0.0.3/Travail_diplome_ES_2020/RESA/api/v2/";